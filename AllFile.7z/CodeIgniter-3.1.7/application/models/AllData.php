<?php
    class AllData extends CI_MODEL{
        public function __construct(){
            $this->load->database();
        }
        public function getAll(){
            return $this->db->get('data')->result_array();
        }public function getById($id){
            $res=$this->db->query('select * from data where id='.$id)->result();
            return $res[0];
        }
    }